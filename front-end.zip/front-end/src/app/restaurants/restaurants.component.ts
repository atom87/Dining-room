import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../service/restaurant.service';
import { RestaurantList } from '../model/restaurant-list';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'dr-restaurants',
  templateUrl: './restaurants.component.html',
  styleUrls: ['./restaurants.component.css']
})
export class RestaurantsComponent implements OnInit {

  restaurantList: RestaurantList;
  parameters = {
    filter: {
      priceFrom: 1,
      priceTo: 5,
      cuisine: ''
    },
    page: 1,
    pageSize: 12
  }
  
  constructor(private service: RestaurantService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(newParams =>{
      let cuisine = newParams['cuisine'] == 'all' ? '' : newParams['cuisine'];

      // isto kao prethodni korak, samo sto je ono bolja varijanta:
      // if(params['cuisine'] == 'all') {
      //   this.filter.cuisine = '';
      // } else {
      //   this.filter.cuisine = params['cuisine'];
      // }

      this.parameters.filter.cuisine = cuisine;
      this.parameters.page = 1;
      this.updateRestaurants();
    })
  }

  updateRestaurants(){
    this.service.getAll(this.parameters).subscribe(data => {
      this.restaurantList = data;
    })
  }
  changePage(newPage){
    this.parameters.page = newPage;
    this.updateRestaurants();
  }

}
