import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'dr-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css']
})
export class PaginationComponent implements OnInit {
  @Input() totalItems: number;
  @Input() pageSize: number;
  @Output() pageChange = new EventEmitter();

  currentPage: number = 1;
  pageCount: number;
  pages: number[];

  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges() {
    this.pageCount = Math.ceil(this.totalItems / this.pageSize)
    this.pages = new Array(this.pageCount);
    this.currentPage = 1;
  }

  changePage(page) {
    this.currentPage = page;
    this.pageChange.emit({"page": this.currentPage});
  }
}
