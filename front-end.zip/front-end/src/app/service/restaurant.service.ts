import { RestaurantList } from './../model/restaurant-list';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { MenuList } from '../model/menu-list';
 
const url ="http://localhost:3000/api/restaurants";

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  constructor(private http: HttpClient) { }

getAll(params? : any): Observable<RestaurantList>{
  let queryParams = {};
  if(params){
    queryParams = {
      params: new HttpParams()
      .set("filter", params.filter && JSON.stringify(params.filter) || "")
      .set("page", params.page && params.page.toString()|| "")
      .set("sort", params.sort && params.sort.toString() || 'rating') //moze i po price da se sortira
      .set("sortDirection", params.sortDirection && params.sortDirection.toString() || 'desc')
      .set("pageSize", params.pageSize && params.pageSize.toString() || "")
    }
  }
  return this.http.get(url, queryParams).pipe(map(response => {
    return new RestaurantList(response);
  }))
}

getMenu(restaurantId: number):Observable<MenuList>{
  return this.http.get<RestaurantList>(url + "/" + restaurantId + "/menus").pipe(map(response => {
    return new MenuList(response);
  }))

}

}
