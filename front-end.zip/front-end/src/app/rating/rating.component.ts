import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dr-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent implements OnInit {
@Input() emptyIcon : string;
@Input() fullIcon : string;
@Input() grade : number;
emptyArray; 
fullArray;
  constructor() { }

  ngOnInit(): void {
    this.emptyArray = new Array(5- this.grade);
    this.fullArray = new Array(this.grade);
  }

}
